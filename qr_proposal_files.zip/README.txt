INSTRUCTIONS

1) Download a romantic animation video from:
https://pixabay.com/videos/search/love%20animation/

2) Rename the video to:
love.mp4

3) Place love.mp4 in the same folder as index.html and style.css

4) Upload all files to GitHub repository root

5) Enable GitHub Pages

6) Generate QR using the GitHub Pages link
